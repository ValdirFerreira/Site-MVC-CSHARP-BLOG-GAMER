﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_GamerBlog.Helpers;

namespace MVC_GamerBlog.Controllers
{
    public class MenuController : BaseController
    {

        public ActionResult Index()
        {

            Session["SetMenu"] = ViewsProject.ViewPrincipal;

            ViewBag.Controller = ControllerProject.Usuario;
            ViewBag.Action = ViewsProject.ViewPrincipal;
            return View(ViewsProject.ViewPrincipal);
        }

        public ActionResult Principal()
        {
            Session["SetMenu"] = ViewsProject.ViewPrincipal;

            ViewBag.Controller = ControllerProject.Usuario;
            ViewBag.Action = ViewsProject.ViewPrincipal;
            return View(ViewsProject.ViewPrincipal);
        }


        public ActionResult Cadastro()
        {
            Session["SetMenu"] = ViewsProject.ViewCadastro;

            ViewBag.Controller = ControllerProject.Usuario;
            ViewBag.Action = ViewsProject.ViewCadastro;
            return View(ViewsProject.ViewCadastro);
        }


        public ActionResult LoginUsuario()
        {
            Session["SetMenu"] = ViewsProject.ViewLoginUsuario;

            ViewBag.Controller = ControllerProject.Usuario;
            ViewBag.Action = ViewsProject.ViewLoginUsuario;
            return View(ViewsProject.ViewLoginUsuario);
        }
    }
}
