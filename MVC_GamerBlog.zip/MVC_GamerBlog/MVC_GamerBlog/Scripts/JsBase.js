﻿$(document).ready(function () {
    exibirPopupMensagem();
});

function exibirPopupMensagem() {
    if ($("#mensagemPopupConteudo").val() == '')
        ExibirPopup('mensagemPopup');
}


(function ($) {
    var getModelPrefix = function (fieldName) {
        return fieldName.substr(0, fieldName.lastIndexOf('.') + 1);
    };

    var appendModelPrefix = function (value, prefix) {
        if (value.indexOf('*.') === 0) {
            value = value.replace('*.', prefix);
        }
        return value;
    };

    $.validator.unobtrusive.adapters.add('equalsto', ['other'], function (options) {
        var prefix = getModelPrefix(options.element.name),
        other = options.params.other,
        fullOtherName = appendModelPrefix(other, prefix),
        element = $(options.form).find(':input[name=' + fullOtherName + ']')[0];

        options.rules['equalsto'] = element;
        if (options.message) {
            options.messages['equalsto'] = options.message;
        }
    });

    $.validator.addMethod('equalsto', function (value, element, params) {
        var secondProperty = $(params).val();
        var firstProperty = value;
        return firstProperty == secondProperty;
    }, '');
})(jQuery);




//Remove os validadores padrão que não funcionam com globalização.
$.validator.addMethod('date', function (value, element) {
    return true;
});
$.validator.addMethod('number', function (value, element) {
    return true;
});
$.validator.addMethod('range', function (value, element) {
    return true;
});


