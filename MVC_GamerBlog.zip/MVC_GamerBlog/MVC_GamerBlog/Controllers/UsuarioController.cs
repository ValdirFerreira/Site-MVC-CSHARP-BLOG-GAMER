﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_GamerBlog.App_LocalResources;
using MVC_GamerBlog.Helpers;
using MVC_GamerBlog.Models;

namespace MVC_GamerBlog.Controllers
{
    public class UsuarioController : MenuController
    {

        [HttpPost]
        public ActionResult Enviar(CadastroUsuarioViewModel cadastroUsuarioViewModel)
        {
            //  MessageBase(AlertStyles.Success, ResourceGlobal.TituloMensagemSucesso, ResourceGlobal.SalvoComSucesso, true);
            MessageBase(AlertStyles.Danger, ResourceGlobal.TituloMensagemErro, ResourceGlobal.VerifiqueFormulario, true);
            return View(ViewsProject.ViewCadastro);
        }
    }
}
