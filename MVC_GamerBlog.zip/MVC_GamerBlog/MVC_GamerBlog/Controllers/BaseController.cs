﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_GamerBlog.Helpers;

namespace MVC_GamerBlog.Controllers
{
    public class BaseController : Controller
    {
        public void ExibirMensagemPopup(string mensagem)
        {
            if (!string.IsNullOrEmpty(mensagem))
            {
                TempData["TempDataPopup"] = mensagem;
            }
        }


        public void MessageBase(string AlertStyles, string titulo, string message, bool dismissable = false)
        {
            message = string.Format("<b>{0}</b> " + message, titulo);
            AddAlert(AlertStyles, message, dismissable);
        }


        public void Success(string message, bool dismissable = false)
        {
            AddAlert(AlertStyles.Success, message, dismissable);
        }

        public void Information(string message, bool dismissable = false)
        {
            AddAlert(AlertStyles.Information, message, dismissable);
        }

        public void Warning(string message, bool dismissable = false)
        {
            AddAlert(AlertStyles.Warning, message, dismissable);
        }

        public void Danger(string message, bool dismissable = false)
        {
            AddAlert(AlertStyles.Danger, message, dismissable);
        }

        private void AddAlert(string alertStyle, string message, bool dismissable)
        {
            var alerts = TempData.ContainsKey(Alert.TempDataKey)
                ? (List<Alert>)TempData[Alert.TempDataKey]
                : new List<Alert>();

            alerts.Add(new Alert
            {
                AlertStyle = alertStyle,
                Message = message,
                Dismissable = dismissable
            });

            TempData[Alert.TempDataKey] = alerts;
        }


    }

}
