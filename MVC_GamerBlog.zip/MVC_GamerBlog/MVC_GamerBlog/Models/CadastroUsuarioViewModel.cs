﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.AccessControl;
using System.Web;
using System.Web.Mvc;
using MVC_GamerBlog.App_LocalResources;
using MVC_GamerBlog.Helpers;


namespace MVC_GamerBlog.Models
{
    public class CadastroUsuarioViewModel
    {
        [Display(ResourceType = typeof(ResourceGlobal), Name = "Login")]
        [Required(ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoObrigatorio)]
        [StringLength(50, ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoMaximoCaracteres)]
        public string Login { get; set; }

        [DataType(DataType.Password)]
        [Display(ResourceType = typeof(ResourceGlobal), Name = "Senha")]
        [Required(ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoObrigatorio)]
        [StringLength(50, ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoMaximoCaracteres)]
        public string Senha { get; set; }

        [Display(ResourceType = typeof(ResourceGlobal), Name = "RepeteSenha")]
        [Compare("Senha", ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoIgual)]
        [RegularExpression(Regexs.Senha, ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoRegexSenha)]
        [StringLength(50, MinimumLength = 10, ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoEntreCaracteres)]
        public string RepeteSenha { get; set; }
    }
}